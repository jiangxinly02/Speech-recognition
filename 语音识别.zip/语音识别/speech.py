import os
import sys
import warnings
import numpy as np
import scipy.io.wavfile as wf
# 梅尔频率倒谱系数
import python_speech_features as sf
# 隐马尔科夫模型
import hmmlearn.hmm as hl


def search_speeches(directory, speeches):
    # 解决路径/\\
    directory = os.path.normpath(directory)
    # os.listdir(directory)列表显示目录
    for entry in os.listdir(directory):
        # 找目录最后一个分隔符，不同系统的分隔符不一样，所以用os.path.sep
        # directory.rfind()返回的是下标位置
        label = directory[directory.rfind(os.path.sep) + 1:]
        # 路径拼接，形成完整路径
        path = os.path.join(directory, entry)
        # 递归找到文件
        if os.path.isdir(path):
            search_speeches(path, speeches)
        # 添加路径下的.wav文件入列表
        elif os.path.isfile(path) and path.endswith('.wav'):
            if label not in speeches:
                speeches[label] = []
            speeches[label].append(path)


def read_signals(filename):
    sample_rate, sigs = wf.read(filename)
    return sigs, sample_rate


def calc_features(sigs, sample_rate):
    mfcc = sf.mfcc(sigs, sample_rate)
    return mfcc


def read_data(directory):
    speeches = {}
    search_speeches(directory, speeches)
    x, y = [], []
    for label, filenames in speeches.items():
        # print(label,filenames)
        mfccs = np.array([])
        for filename in filenames:
            sigs, sample_rate = read_signals(filename)
            mfcc = calc_features(sigs, sample_rate)
            mfccs = mfcc if len(mfccs) == 0 else \
                np.append(mfccs, mfcc, axis=0)
        x.append(mfccs)
        y.append(label)
    return x, y


def train_models(x, y):
    models = {}
    for mfccs, label in zip(x, y):
        model = hl.GaussianHMM(n_components=4,
                               covariance_type='diag', n_iter=1000)
        models[label] = model.fit(mfccs)
    return models


def pred_models(models, x):
    y = []
    for mfccs in x:
        best_score, best_label = None, None
        for label, model in models.items():
            score = model.score(mfccs)
            if best_score is None:
                best_score = score
            if best_label is None:
                best_label = label
            if best_score < score:
                best_score, best_label = score, label
        y.append(best_label)
    return y


def main(argc, argv, envp):
    warnings.filterwarnings('ignore',
                            category=DeprecationWarning)
    np.seterr(all='ignore')
    train_x, train_y = read_data('speeches/training')
    test_x, test_y = read_data('speeches/testing')
    models = train_models(train_x, train_y)
    pred_test_y = pred_models(models, test_x)
    for y, pred_y in zip(test_y, pred_test_y):
        print(y, pred_y)
    return 0


if __name__ == '__main__':
    sys.exit(main(len(sys.argv), sys.argv, os.environ))
